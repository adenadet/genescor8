<template>
<div>
    <p>Let us put the various settings that we think about later here.</p>
</div>
</template>