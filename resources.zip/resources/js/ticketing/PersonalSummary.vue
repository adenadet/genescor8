<template>
    
</template>
<script>
export default{
    props:{
        'completed': Array,
        'total': Array,
        'open': Number,
        'assigned': Number,
    }
}
</script>
