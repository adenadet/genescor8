<template>
    <p>If we want to create reports, we would put this here! However only people with Access rights would be ablee to do this</p>
</template>
<script>

</script>