<footer class="main-footer">
    <div class="float-right d-none d-sm-inline"><a href="https://squarem.com.ng">SKP Consultancy</a></div>
    <strong>Copyright &copy; 2014-2021 Genescor App.</strong> All rights reserved.
</footer>