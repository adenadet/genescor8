<div class="col-12">
    <p style="font-family: 'Work Sans'; font-style: normal; font-weight: 400; font-size: 14px; line-height: 16px;">By creating an account, you agree to Genescor's <a class="text-danger" href="#">Terms of Service</a> and <a class="text-danger" href="#">Privacy Policy</a></p>     
</div>